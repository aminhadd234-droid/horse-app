# Frontend Project
Next.js frontend skeleton.